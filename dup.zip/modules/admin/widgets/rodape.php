<script type="text/javascript">
    $(function(){
        // ajax of actions

       //chamadas FB

        // This is called with the results from from FB.getLoginStatus().
        function statusChangeCallback(response) {
            if (response.status === 'connected') {
                FB.api({
                    method: 'fql.query',
                    query:  'SELECT friend_count FROM user WHERE uid = me()'
                }, function(resp) {
                    if (resp.length) {
                        console.log(resp);
                    }
                });
            } else if (response.status === 'not_authorized') {
                notification.error('Não foi possivel conectar-se com o facebook');
            } else {
                document.getElementById('status').innerHTML = 'Please log ' +
                'into Facebook.';
            }
        }

        window.fbAsyncInit = function() {
            FB.init({
                appId      : '1651604578442142',
                cookie     : true,  // enable cookies to allow the server to access
                                    // the session
                xfbml      : true,  // parse social plugins on this page
                version    : 'v2.2' // use version 2.2
            });


            // Logged into your app and Facebook.

            // Now that we've initialized the JavaScript SDK, we call
            // FB.getLoginStatus().  This function gets the state of the
            // person visiting this page and can return one of three states to
            // the callback you provide.  They can be:
            //
            // 1. Logged into your app ('connected')
            // 2. Logged into Facebook, but not your app ('not_authorized')
            // 3. Not logged into Facebook and can't tell if they are logged into
            //    your app or not.
            //
            // These three cases are handled in the callback function.

            FB.getLoginStatus(function(response) {
                statusChangeCallback(response);
            });
        };

        // Load the SDK asynchronously
        (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s); js.id = id;
            js.src = "//connect.facebook.net/en_US/sdk.js";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));



        $(".fn").on("click", function(){
            var url = $(this).data('url');
            var title = $(this).data('title');
            var id = $(this).data('id');


            $.ajax({
                url: '<?=$endereco?>'+url,
                type: 'post',
                data: "id="+id,
                datatype: 'html',
                beforeSend: function(){
                    //$('.progress-bar').show();
                },
                complete: function() {
                    //$('.progress-bar').fadeOut();
                },
                success: function(e){
                    $('.modal-title').html(title);
                    $('.modal-body').html(e);
                    $('#modalUses').modal('show');
                }
            });
        });


        $("#formEditUser").on("submit",function(){
            event.preventDefault();
            var url = $(".editForm").data('url');

            if($(".editForm").data('url') != null)
                url = '<?=$endereco?>'+$(".editForm").data('url');
            else if($(".urlTrasiction").data('url') != null)
                url = $(".urlTrasiction").data('url');

            $.ajax({
                url: url,
                type: 'post',
                data:  new FormData(this),
                datatype: 'html',
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function(){
                    $('.progress-bar').show();
                },
                complete: function() {
                    $('.progress-bar').fadeOut();
                },
                success: function(e){
                    window.location.reload();
                    //console.log(e);

                }
            });
        });
    });
</script>
</body>
</html>