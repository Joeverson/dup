<?php
include "modules/admin/widgets/header.php";
include "modules/admin/widgets/sidebar.php";

?>
        <div class="container" style="margin-top: 30px;">
            <div class="row">
                <div class="container">
                    <div class="col-md-12">
                        <h2 style="color:white; font-weight: bold" class="text-center text-captalize">Olá, tudo bem? <br/>O que vamos fazer hoje?</h2>
                        <p></p>
                    </div>
                </div>
            </div>
       </div>
    <main class="mdl-layout__content">
    </main>



<?php
include "modules/admin/widgets/rodape.php";
?>
