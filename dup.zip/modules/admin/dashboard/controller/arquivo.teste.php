<?php
namespace Veia\controller;

class ClassTest{
    public function casa(){
        echo "eita meu vei a casa pegou";
    }
    public function veia(){
        echo "eita veia gostosa";
    }
}