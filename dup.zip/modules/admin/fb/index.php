<?php
include "modules/admin/widgets/header.php";
include "modules/admin/widgets/sidebar.php";

$slider = new modules\admin\slider\model\DBSlide;
?>
    <!-- Wide card with share menu button -->
    <style>
        .demo-card-wide.mdl-card {
            width: 100%;
            margin-top: 20px;
        }
        .demo-card-wide > .mdl-card__title {
            color: #fff;
            height: 276px;
            background: linear-gradient(rgba(0,0,0,0.2), rgba(0,0,0,0.2)),url('<?=$endereco?>includes/img/<?=$slider->getSliderForType(1)['url']?>') center / cover;
        }
        .demo-card-wide > .mdl-card__menu {
            color: #fff;
        }
    </style>

<!-- depois tirar essa parte de cima e jogar em algum lugar generico pq ele esta sendo repetido em varios arquivos -->


    <div class="container">
        <?php
        $fb = new libs\facebook;

        $helper = $fb->getRedirectLoginHelper();
        try {
            $accessToken = $helper->getAccessToken();
        } catch(\Facebook\Exceptions\FacebookResponseException $e) {
            // When Graph returns an error
            echo 'Graph returned an error: ' . $e->getMessage();
            exit;
        } catch(\Facebook\Exceptions\FacebookSDKException $e) {
            // When validation fails or other local issues
            echo 'Facebook SDK returned an error: ' . $e->getMessage();
            exit;
        }

        if (isset($accessToken)) {
            // Logged in!
            $_SESSION['facebook_access_token'] = (string) $accessToken;

            // Now you can redirect to another page and use the
            // access token from $_SESSION['facebook_access_token']
        }

        ?>
    </div>
    <script>
        $(function(){


        });
    </script>
<?php include "modules/admin/widgets/rodape.php"; ?>