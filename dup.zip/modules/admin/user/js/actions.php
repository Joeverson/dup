<?php
header("Content-type: text/javascript");


?>
$('.add_user').click(function(){
    $('.addUsers').modal('show');
});