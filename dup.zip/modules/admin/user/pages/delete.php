<div class="container-fluid editForm" data-url="user/delete/<?=$id?>">
    <div class="row">
        <!--div class="alert alert-danger alert-dismissable"-->
            <h4>Atenção!</h4>
            <p>Deseja realmente deletar este usuário? Clique em continuar.</p>
            <!--p><a class="btn btn-danger" href="#">Não, me tire daqui!!</a> <a class="btn btn-link" href="#">Sim</a></p-->
        <!--/div-->
    </div>
</div>